#ifndef UTILS_H_INCLUDED
#define UTILS_H_INCLUDED

#ifdef __cplusplus
extern "C"
#endif
int * ProcessData(int data) ;



#endif // UTILS_H_INCLUDED
